"""Return live facts directly; never turn an API failure into invented data."""
from __future__ import annotations
import time
from .heuristics import detect_api_intent
from .api_tools import get_crypto_price, get_news, get_weather
from .local_model import LocalModelResponse


def unavailable_response(prompt: str, message: str) -> LocalModelResponse:
    return LocalModelResponse(prompt=prompt, text=message, model='api-unavailable',
        latency_s=0.0, tokens_used=None, raw={}, route='API_CHECK',
        route_reason='live_data_unavailable', warning='No current facts were retrieved.')


def run_api_check(prompt: str, *, system_prompt: str | None = None,
                  temperature: float = 0.7, max_tokens: int = 512) -> LocalModelResponse:
    intent = detect_api_intent(prompt)
    if intent is None:
        return unavailable_response(prompt, 'This question needs current information, but SEVEN only supports weather, crypto prices and news tools. Please check a current source.')
    started = time.perf_counter()
    try:
        text = {'weather': get_weather, 'crypto': get_crypto_price, 'news': get_news}[intent](prompt)
    except Exception:
        # Exceptions from HTTP clients may contain API keys in their URL.
        text = f'{intent.capitalize()} data unavailable. Please try again later.'
    if 'unavailable' in text.lower():
        result = unavailable_response(prompt, text)
    else:
        result = LocalModelResponse(prompt=prompt, text=text, model='api-direct',
            latency_s=0.0, tokens_used=None, raw={}, route='API_CHECK', route_reason='live_data_retrieved')
    result.latency_s = time.perf_counter() - started
    return result
