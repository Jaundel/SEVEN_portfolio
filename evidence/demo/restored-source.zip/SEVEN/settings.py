"""Load local configuration without replacing exported environment variables."""
from pathlib import Path
from dotenv import load_dotenv


def load_settings(root: Path | None = None) -> None:
    root = root or Path(__file__).resolve().parents[1]
    load_dotenv(root / ".env.local", override=False)
    load_dotenv(root / ".env", override=False)
