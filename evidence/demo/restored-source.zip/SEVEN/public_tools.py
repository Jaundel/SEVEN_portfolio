"""Public live-data defaults for the personal, non-commercial CLI.

Open-Meteo weather/geocoding, Coinbase spot prices and BBC RSS.
Each response identifies its source, time and the scope of the retrieved data.
"""
from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
import re
import xml.etree.ElementTree as ET

import requests

TIMEOUT = 10
HEADERS = {'User-Agent': 'SEVEN/1.0 (personal research CLI)'}


def _json(url: str, params: dict | None = None) -> dict:
    response = requests.get(url, params=params, headers=HEADERS, timeout=TIMEOUT)
    response.raise_for_status()
    return response.json()


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def weather(prompt: str) -> str:
    match = re.search(r'\b(?:in|at|for)\s+(.+)', prompt, re.IGNORECASE)
    if not match:
        return 'Weather data unavailable. Include a city, for example: weather in Toronto.'
    location = re.split(r'\b(?:right now|today|tomorrow|this week|in celsius|in fahrenheit)\b',
                        match.group(1), flags=re.IGNORECASE)[0].strip(' ?!.,')
    if not location:
        return 'Weather data unavailable. Please include a city.'
    try:
        matches = _json('https://geocoding-api.open-meteo.com/v1/search',
                        {'name': location, 'count': 1, 'language': 'en', 'format': 'json'}).get('results', [])
        if not matches:
            return f'Weather data unavailable: no location found for {location}.'
        city = matches[0]
        name = ', '.join(str(city[k]) for k in ('name', 'admin1', 'country') if city.get(k))
        params = {'latitude': city['latitude'], 'longitude': city['longitude'], 'timezone': 'auto',
                  'current': 'temperature_2m,relative_humidity_2m,wind_speed_10m',
                  'daily': 'temperature_2m_max,temperature_2m_min,precipitation_probability_max',
                  'forecast_days': 2}
        if re.search(r'\bfahrenheit\b', prompt, re.IGNORECASE):
            params['temperature_unit'] = 'fahrenheit'
        data = _json('https://api.open-meteo.com/v1/forecast', params)
        if re.search(r'\b(?:tomorrow|forecast)\b', prompt, re.IGNORECASE):
            day = 1 if re.search(r'\btomorrow\b', prompt, re.IGNORECASE) else 0
            daily = data['daily']; units = data['daily_units']
            return (f"{name} — forecast for {daily['time'][day]}: "
                    f"{daily['temperature_2m_min'][day]} to {daily['temperature_2m_max'][day]} "
                    f"{units['temperature_2m_max']}; maximum precipitation probability "
                    f"{daily['precipitation_probability_max'][day]}%.\n"
                    f"Source: Open-Meteo weather models (https://open-meteo.com/). Retrieved {_utc()}.")
        current = data['current']; units = data['current_units']
        return (f"{name} — {current['temperature_2m']} {units['temperature_2m']}, "
                f"humidity {current['relative_humidity_2m']}%, wind {current['wind_speed_10m']} "
                f"{units['wind_speed_10m']}.\nModelled conditions for {current['time']} "
                f"({data.get('timezone', 'UTC')}). Source: Open-Meteo (https://open-meteo.com/). "
                f"Retrieved {_utc()}.")
    except (requests.RequestException, ValueError, KeyError, IndexError, TypeError):
        return 'Weather data unavailable. Open-Meteo did not return usable data; try again later.'


COINS = {'bitcoin': 'BTC', 'btc': 'BTC', 'ethereum': 'ETH', 'eth': 'ETH',
         'solana': 'SOL', 'sol': 'SOL', 'dogecoin': 'DOGE', 'doge': 'DOGE'}


def crypto(prompt: str) -> str:
    symbols = {symbol for alias, symbol in COINS.items()
               if re.search(r'(?<!\w)' + re.escape(alias) + r'(?!\w)', prompt, re.IGNORECASE)}
    if len(symbols) != 1:
        return 'Crypto price unavailable. Specify one supported asset: BTC, ETH, SOL or DOGE.'
    symbol = symbols.pop()
    try:
        data = _json(f'https://api.coinbase.com/v2/prices/{symbol}-USD/spot')['data']
        price = Decimal(data['amount'])
        if not price.is_finite() or price <= 0 or data['currency'] != 'USD' or data.get('base', symbol) != symbol:
            raise ValueError('Invalid price')
        return (f'{symbol}: ${price:,.2f} USD — Coinbase spot quote. Retrieved {_utc()}.\n'
                f'Source: https://api.coinbase.com/v2/prices/{symbol}-USD/spot')
    except (requests.RequestException, ValueError, ArithmeticError, KeyError, TypeError):
        return 'Crypto price unavailable. Coinbase did not return a usable spot quote; try again later.'


def news(prompt: str) -> str:
    section = next((name for name in ('technology', 'business', 'science_and_environment')
                    if name.split('_')[0] in prompt.lower()), 'world')
    url = f'https://feeds.bbci.co.uk/news/{section}/rss.xml'
    try:
        response = requests.get(url, headers=HEADERS, timeout=TIMEOUT)
        response.raise_for_status()
        item = ET.fromstring(response.content).find('./channel/item')
        if item is None:
            raise ValueError('Empty feed')
        title, link = item.findtext('title'), item.findtext('link')
        if not title or not link or not link.startswith(('https://www.bbc.', 'https://bbc.')):
            raise ValueError('Invalid feed entry')
        return (f"Latest entry in BBC {section.replace('_', ' ')} feed:\n{title}\n"
                f"Published: {item.findtext('pubDate', 'not supplied')}. Retrieved {_utc()}.\n"
                f"{link}\nThis is one feed entry, not an exhaustive search of the requested topic.")
    except (requests.RequestException, ValueError, ET.ParseError):
        return 'News data unavailable. BBC did not return a usable RSS entry; try again later.'
