"""Terminal commands for SEVEN, also available as ``python -m SEVEN``."""
from __future__ import annotations

import argparse
import json
import os
import sys
from urllib.parse import urlsplit
from dataclasses import asdict

from .settings import load_settings


def doctor() -> dict:
    import requests
    from .local_model import _base_url, _model_name
    base = _base_url()
    info = {"local_url": base, "local_model": _model_name(),
            "cloud_model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            "cloud_key_configured": bool(os.getenv("OPENAI_API_KEY")),
            "live_keys_configured": {k: bool(os.getenv(k)) for k in
                ("OPENWEATHER_API_KEY", "COINDESK_API_KEY", "NEWS_API_KEY")},
            "energy": "Profile estimates only; no hardware power meter attached."}
    info['default_live_providers'] = {'weather': 'Open-Meteo', 'crypto': 'Coinbase spot', 'news': 'BBC RSS'}
    try:
        response = requests.get(base.rstrip('/') + '/models', timeout=5)
        if response.status_code == 404:
            parsed = urlsplit(base)
            response = requests.get(f'{parsed.scheme}://{parsed.netloc}/health', timeout=5)
            response.raise_for_status()
            health = response.json()
            info['local_ready'] = health.get('status') == 'ok'
            info['backend_mode'] = health.get('execution_mode')
        else:
            response.raise_for_status()
            info['local_ready'] = True
            info['models'] = [x['id'] for x in response.json().get('data', [])]
    except (requests.RequestException, ValueError, KeyError):
        info['local_ready'] = False
        info['local_error'] = 'Local backend unavailable. Start Lemonade and check LEMONADE_BASE_URL.'
    return info


def main(argv: list[str] | None = None) -> int:
    load_settings()
    parser = argparse.ArgumentParser(description="SEVEN: inspect routing or run a prompt.")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--ask', metavar='PROMPT')
    action.add_argument('--classify', metavar='PROMPT')
    action.add_argument('--doctor', action='store_true')
    parser.add_argument('--cloud', action='store_true', help='Send this prompt directly to OpenAI.')
    parser.add_argument('--no-escalate', action='store_true', help='Return local uncertainty without cloud escalation.')
    parser.add_argument('--json', action='store_true', help='Emit one JSON object, without terminal animation.')
    parser.add_argument('--max-tokens', type=int, default=512)
    args = parser.parse_args(argv)
    if args.json:
        os.environ['SEVEN_NO_SPINNER'] = '1'
    try:
        if args.doctor:
            payload = doctor()
        elif args.classify is not None:
            from .heuristics import classify_query_type
            payload = classify_query_type(args.classify)
        else:
            from .router import route_prompt
            if not 1 <= args.max_tokens <= 32768:
                raise ValueError('--max-tokens must be between 1 and 32768.')
            result = route_prompt(args.ask, use_cloud=args.cloud,
                auto_escalate=not args.no_escalate, max_tokens=args.max_tokens)
            payload = asdict(result)
            payload.pop('raw', None)
            payload['energy_basis'] = 'Configured profile estimate; not measured electricity.'
        if args.json:
            print(json.dumps(payload, ensure_ascii=False))
        elif 'text' in payload:
            print(payload['text'])
            print(f"\n{payload['route']} · {payload['model']} · {payload['latency_s']:.2f}s")
            if payload.get('warning'):
                print('Warning: ' + payload['warning'])
            if payload.get('energy'):
                print(f"Estimated energy: {payload['energy']['watt_hours']:.5f} Wh (profile assumption)")
        else:
            print(json.dumps(payload, indent=2, ensure_ascii=False))
        return 0
    except (RuntimeError, ValueError) as exc:
        if args.json:
            print(json.dumps({'error': str(exc)}))
        else:
            print(str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
