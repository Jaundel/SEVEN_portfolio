# SEVEN

SEVEN (Sustainable Energy Via Efficient Neural-routing) is a terminal chat application that chooses a compute path before answering. Phrase rules send short general questions to a local model, supported current-data questions to source-labelled tools, and complex prompts to OpenAI. Explicit uncertainty in a local response can trigger cloud escalation.

The rules are heuristics, and the small local model can answer incorrectly without expressing uncertainty. Energy numbers in the app are configured profile estimates; they do not establish measured electricity use or cloud savings. Live-data responses preserve provider facts without model rewriting.

## Tech Stack
- Language: Python 3.12.10
- Local Runtime: Lemonade Server (hybrid NPU/GPU/CPU inference) with small language models (1B-3B parameters recommended)
- Cloud Fallback: OpenAI, configurable through `OPENAI_MODEL` (default `gpt-4o-mini`)
- Live tools: Open-Meteo weather, Coinbase spot quotes, BBC RSS; optional keyed provider overrides
- Interface: the bundled Elia/Textual app, plus a JSON CLI

## Setup
See [SETUP.md](SETUP.md) for installation, startup, backend configuration, and verification commands.

## Team Roles & Files
- Jaundel — Local Model Developer — `local_model.py`: Integrate Lemonade Server, send prompts to local small language models, and return responses with retry logic.
- Samin — Cloud Developer — `cloud_model.py`: Manage Groq/OpenAI credentials, forward prompts to cloud backends, and normalize replies.
- Yusuf — Router/Classifier Developer — `router.py`, `prompts.py`: Classify EASY/HARD/UNSAFE prompts, choose the right model, and manage prompt templates plus guardrails.
- Hamanpreet — Energy/Timer Developer — `energy.py`: Track runtime, estimate energy in Wh, and highlight savings vs. cloud-only runs.
- Aadil — CLI/Display Developer — `main.py`: Provide the terminal UX, gather user input, call the router, and display results plus energy metrics.

## Documentation & Collaboration
- Every Python file starts with the shared SEVEN header block (file, project, description, authors, date) plus a module-level docstring for quick context.  
- Functions follow Google-style docstrings including Args/Returns/Raises/TODO to keep contracts explicit across teammates.  
- Inline comments explain “why” decisions, and each module stays independently testable while work moves through branches and pull requests so ownership remains equal.
