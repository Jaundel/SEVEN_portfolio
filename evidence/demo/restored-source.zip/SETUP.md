# Run SEVEN

Use Python 3.12 from this repository's root. On Windows:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r SEVEN\requirements.txt
.\.venv\Scripts\python.exe -m pip install --no-deps -e apps\elia
```

The Windows requirements omit Textual's optional syntax extra because its
tree-sitter dependency does not provide the required Windows wheels.

## Local inference

The launcher supports the Ryzen AI server and hybrid Llama model already
installed on this laptop. It checks port 8081, prepares a separate runtime
directory under `output/runtime`, and starts the backend when needed. It
hardlinks the cached weights and copies the tokenizer configuration so that
the bundled chat template is available without changing the model cache.
It does not install the server or download model weights on another machine.

```powershell
.\Start-SEVEN.ps1 -Doctor -Json
.\Start-SEVEN.ps1
.\Start-SEVEN.ps1 -Ask 'What is the capital of France?' -NoEscalate -Json
```

With another running OpenAI-compatible local backend, put its settings in
`.env.local` and use the Python entry point directly:

```dotenv
LEMONADE_BASE_URL=http://127.0.0.1:8081/v1
LEMONADE_MODEL=Llama-3.2-1B-Instruct-Hybrid
LEMONADE_TIMEOUT_SECONDS=120
```

```powershell
.\.venv\Scripts\python.exe cli.py --doctor --json
.\.venv\Scripts\python.exe cli.py
```

Startup reads `.env.local`, then `.env`. Exported environment variables take
precedence. Both files are ignored by Git. Keep credentials out of command
arguments, screenshots and version control.

## Cloud and live data

OpenAI routes require `OPENAI_API_KEY` in the process environment or ignored
local env file. `OPENAI_MODEL` selects the cloud model. No key is bundled.
A missing key produces a visible error, and the input remains available to
edit and retry. Cloud routing sends the prompt and conversation context to
the configured provider.

```powershell
.\Start-SEVEN.ps1 -Ask 'Explain quantum entanglement in two sentences.' -Cloud -Json
.\Start-SEVEN.ps1 -Ask 'weather in Toronto right now' -Json
.\Start-SEVEN.ps1 -Ask 'BTC price now' -Json
.\Start-SEVEN.ps1 -Ask 'latest technology news' -Json
```

The default live tools use Open-Meteo, Coinbase and BBC RSS without keys.
Weather needs a city; crypto quotes need a supported asset (BTC, ETH, SOL,
DOGE). News returns one entry from a selected BBC category feed, rather than
a complete topic search. Replies include sources and timestamps. Provider
failures remain explicit instead of being replaced by model-generated facts.
`OPENWEATHER_API_KEY`, `COINDESK_API_KEY`, and `NEWS_API_KEY` retain the optional
legacy provider paths when configured.

## Interface and verification

Type a prompt and press `Ctrl+J` or `Alt+Enter`. `F1` opens help; `Ctrl+O`
opens estimate profiles. Changing profiles changes the estimate coefficients,
not the model or hardware. These values are not electricity measurements.

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -m pip check
powershell.exe -NoProfile -File tools\verify_cli.ps1
.\.venv\Scripts\python.exe tools\verify_tui.py
.\.venv\Scripts\python.exe tools\verify_tui.py --visible --record
```

The TUI verification uses real local inference and provider requests. It
stores its own chats, renderer frames and JSON report under
`output/evidence/<UTC timestamp>`, separate from personal chat history.
It checks expected missing-key handling when no cloud key is configured;
that does not verify a successful cloud request.

To export recorded native renderer frames as a video:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-demo.txt
.\.venv\Scripts\python.exe tools\render_recording.py output\evidence\<UTC-timestamp>
```

The MP4 replays the captured frames at their original timings. It is a
recording of the application's renderer, not a full desktop screen capture.
Visible runs use normal application mode and follow the terminal size;
fixed-size test mode is limited to the headless verification.

For a complete maximized Windows Terminal recording, including its title bar:

```powershell
.\.venv\Scripts\python.exe tools\capture_full_window.py
```

This uses Windows Graphics Capture at the window's native dimensions, with
no crop or resize. It requires Windows Terminal and `requirements-demo.txt`.
The recording runs the real verification flow with live provider requests,
including a cloud request when configured. Evidence and checkpoint PNGs go
under `output/full-window/<UTC timestamp>`; chat history remains isolated.

To enter an existing OpenAI key without displaying it or putting it in shell
history, run `powershell.exe -NoProfile -File tools\Set-CloudKey.ps1`.
The prompt names the ignored destination before accepting masked input.
