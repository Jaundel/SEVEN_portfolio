# Restoration verification — 14 November 2026

SEVEN was checked on the Windows laptop using its own `.venv`, the cached
Llama 3.2 1B hybrid Ryzen AI runtime, and the user's configured OpenAI key.
No key was created through the connector. The supplied existing key was entered
through a masked terminal prompt and saved to the ignored `.env.local`.

## Verified behavior

- `Start-SEVEN.ps1 -Doctor -Json`: local backend ready, hybrid execution,
  cloud credential present. Port 8081 is owned by the app runtime.
- Real launcher requests: local Paris answer, Open-Meteo Toronto weather,
  Coinbase BTC quote, BBC technology RSS entry, and OpenAI cloud response.
  See `output/evidence/cli-20261114T205909Z/report.json`.
- Real TUI: local and live routes, cloud reply, returning to local inference,
  profile selection/reset, saved route label, rename, details, and archive.
  See `output/evidence/20261114T210017Z/report.json`.
- Missing-key failure followed by a successful local reply in the same chat
  was verified before the key was supplied. See
  `output/evidence/20261114T205534Z/report.json`.
- Headless layout checks passed at 80×24, 160×50, 100×30, 190×48, and
  118×38. See `output/evidence/resize-20261114T210619Z/report.json`.
  These are injected layout events, not observations of Windows maximizing.
- `python -m unittest discover -s tests -p test_restoration.py -v`: 19 passed.
  Includes repairing an existing empty database without deleting an existing
  table, and quitting the TUI without leaving database threads running.
- `python -m pip check`: no broken requirements. `git diff --check`: clean.

The original PROJECT SEVEN gradient banner was restored after an interim
compact version. Visible walkthroughs now use normal application mode and
the actual terminal size, rather than a forced test viewport. The walkthrough
launcher clears the display after the app exits. The normal interactive app
is opened with `tools/Show-SEVEN.ps1` or `Start-SEVEN.ps1`.

## Actual application recording

`output/evidence/20261114T210017Z/seven-walkthrough.mp4` replays 161 captured
native renderer frames over approximately 73 seconds. Frames retain their
original timing; resizing is handled by padding, without stretching text.
The video decoded successfully with FFmpeg. This is an application renderer
recording, not a full desktop screen capture or a generated product mockup.

## Limits

These checks establish functional behavior, not answer accuracy. The small
local model produced incorrect explanations without expressing uncertainty;
phrase-based routing and uncertainty checks do not reliably detect those
errors. Original replies remain in the reports.

Energy figures in the interface are configured profile estimates. They are
not measured electricity consumption, and the cloud comparison does not
establish actual savings. No new energy benchmark was run during this
restoration verification. Portfolio article work remains paused.
