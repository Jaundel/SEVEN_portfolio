param(
    [string]$Ask,
    [switch]$Doctor,
    [switch]$Cloud,
    [switch]$Json,
    [switch]$NoEscalate,
    [ValidateRange(1,65535)][int]$Port = 8081
)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$pythonPath = Join-Path $projectRoot '.venv\Scripts\python.exe'
if (($Cloud -or $NoEscalate) -and -not $Ask) { throw '-Cloud and -NoEscalate require -Ask.' }
if ($Json -and -not ($Ask -or $Doctor)) { throw '-Json requires -Ask or -Doctor.' }
if (-not (Test-Path -LiteralPath $pythonPath)) {
    throw 'SEVEN environment missing. Follow SETUP.md to install .venv first.'
}

# This launcher starts the installed Ryzen AI runtime. Other backends can use cli.py directly.
$healthUrl = "http://127.0.0.1:$Port/health"
$ready = $false
try { $ready = (Invoke-RestMethod -Uri $healthUrl -TimeoutSec 2).status -eq 'ok' } catch {}
if (-not $ready) {
    $runtimeExe = Join-Path $env:USERPROFILE '.cache\lemonade\bin\ryzenai-server\npu\ryzenai-server.exe'
    if (-not (Test-Path -LiteralPath $runtimeExe)) {
        throw 'Installed Ryzen AI server not found. Start Lemonade separately and use python cli.py.'
    }
    $runtimeModel = & $pythonPath (Join-Path $projectRoot 'tools\prepare_runtime.py')
    if ($LASTEXITCODE -ne 0) { throw 'Could not prepare the local model.' }
    $logRoot = Join-Path $projectRoot 'output\runtime'
    $serverProcess = Start-Process -FilePath $runtimeExe -ArgumentList @('-m', ('"' + $runtimeModel + '"'), '--port', $Port) -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $logRoot 'server.log') -RedirectStandardError (Join-Path $logRoot 'server-error.log')
    $serverProcess.Id | Set-Content -LiteralPath (Join-Path $logRoot 'server.pid')
    for ($attempt = 0; $attempt -lt 90; $attempt++) {
        if ($serverProcess.HasExited) { throw 'Local server exited. See output/runtime/server-error.log.' }
        try { $ready = (Invoke-RestMethod -Uri $healthUrl -TimeoutSec 2).status -eq 'ok' } catch {}
        if ($ready) { break }
        Start-Sleep -Seconds 1
    }
    if (-not $ready) { throw 'Local server did not become ready. See output/runtime/server.log.' }
}
$env:LEMONADE_BASE_URL = "http://127.0.0.1:$Port/v1"
$env:LEMONADE_MODEL = 'Llama-3.2-1B-Instruct-Hybrid'
$env:LEMONADE_TIMEOUT_SECONDS = '120'
$cliArgs = @((Join-Path $projectRoot 'cli.py'))
if ($Doctor) { $cliArgs += '--doctor' }
elseif ($Ask) { $cliArgs += @('--ask', $Ask) }
if ($Cloud) { $cliArgs += '--cloud' }
if ($Json) { $cliArgs += '--json' }
if ($NoEscalate) { $cliArgs += '--no-escalate' }
& $pythonPath @cliArgs
exit $LASTEXITCODE
