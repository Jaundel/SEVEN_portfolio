# Smoke-test actual launcher requests against the installed runtime and live tools.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$stamp = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ')
$outputRoot = Join-Path $projectRoot "output\evidence\cli-$stamp"
New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
$results = @()
$cases = @(
    @{ Name = 'doctor'; Args = @('-Doctor','-Json'); Expected = $null },
    @{ Name = 'local'; Args = @('-Ask','What is the capital of France?','-NoEscalate','-Json'); Expected = 'LOCAL' },
    @{ Name = 'weather'; Args = @('-Ask','weather in Toronto right now','-Json'); Expected = 'API_CHECK' },
    @{ Name = 'crypto'; Args = @('-Ask','BTC price now','-Json'); Expected = 'API_CHECK' },
    @{ Name = 'news'; Args = @('-Ask','latest technology news','-Json'); Expected = 'API_CHECK' },
    @{ Name = 'cloud'; Args = @('-Ask','Explain quantum entanglement in two sentences.','-Cloud','-Json'); Expected = 'CLOUD' }
)
foreach ($case in $cases) {
    $caseArgs = $case.Args
    $raw = & powershell.exe -NoProfile -File (Join-Path $projectRoot 'Start-SEVEN.ps1') @caseArgs
    $code = $LASTEXITCODE
    $data = ($raw -join "`n") | ConvertFrom-Json
    $missingKey = $case.Name -eq 'cloud' -and $data.error -eq 'Missing OPENAI_API_KEY environment variable.'
    if ($missingKey) {
        if ($code -ne 1) { throw 'Missing cloud key must return exit code 1.' }
    } elseif ($code -ne 0) { throw "$($case.Name) failed with exit $code." }
    elseif ($case.Name -eq 'doctor') {
        if (-not $data.local_ready) { throw 'Local backend is not ready.' }
    } elseif ($data.route -ne $case.Expected) { throw "$($case.Name) used route $($data.route)." }
    if ($case.Name -eq 'local' -and $data.text -notmatch 'Paris') { throw 'Local answer was incorrect.' }
    if ($case.Name -in @('weather','crypto','news') -and $data.model -ne 'api-direct') { throw 'Live provider did not return data directly.' }
    $results += @{ case = $case.Name; exit_code = $code; expected_missing_key = $missingKey; response = $data }
    if ($missingKey) { Write-Host 'cloud: expected missing-key error handled (cloud success unverified)' }
    else { Write-Host "$($case.Name): passed" }
}
@{ utc = $stamp; passed = $true; results = $results } | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $outputRoot 'report.json') -Encoding utf8
Write-Host "Evidence: $outputRoot"
