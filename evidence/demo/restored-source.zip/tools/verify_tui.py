"""Exercise the real SEVEN TUI and optionally record its native renderer.

No model or provider is mocked. A separate database holds only these demo chats.
Run with the project venv after Start-SEVEN.ps1 -Doctor has prepared the backend.
"""
from __future__ import annotations

import argparse
import asyncio
from contextlib import asynccontextmanager
import datetime as dt
import faulthandler
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "apps" / "elia"))


async def walkthrough(args, output: Path, report: dict) -> None:
    # Set XDG paths before importing the database or application configuration.
    os.environ["XDG_DATA_HOME"] = str(output / "data")
    os.environ["XDG_CONFIG_HOME"] = str(output / "config")
    os.environ["SEVEN_NO_SPINNER"] = "1"
    # Record the native theme even when the automation shell requests no ANSI.
    os.environ.pop("NO_COLOR", None)
    os.environ["TEXTUAL_COLOR_SYSTEM"] = "truecolor"
    from SEVEN.settings import load_settings
    load_settings()
    from elia_chat.app import Elia
    from elia_chat.chats_manager import ChatsManager
    from elia_chat.config import LaunchConfig
    from elia_chat.database.database import create_database, engine
    import elia_chat.database.models  # Register SQLModel tables.
    from elia_chat.screens.home_screen import HomeScreen
    from elia_chat.screens.help_screen import HelpScreen
    from elia_chat.screens.chat_details import ChatDetails
    from elia_chat.screens.rename_chat_screen import RenameChat
    from elia_chat.widgets.agent_is_typing import ResponseStatus
    from elia_chat.widgets.chat import Chat
    from elia_chat.widgets.chat_list import ChatList
    from elia_chat.widgets.chat_options import OptionsModal
    from elia_chat.widgets.chatbox import Chatbox
    from elia_chat.widgets.prompt_input import PromptInput
    from textual.widgets import RadioSet

    await create_database()
    app = Elia(LaunchConfig())
    frames = output / "frames"
    frames.mkdir()
    started = time.monotonic()

    def capture(label: str | None = None) -> None:
        if not args.record and label is None:
            return
        name = f"frame-{len(report['frames']):05d}.svg"
        (frames / name).write_text(app.export_screenshot(title="SEVEN"), encoding="utf-8")
        report["frames"].append({"file": name, "elapsed_s": time.monotonic() - started,
                                 "terminal_size": list(app.size), "checkpoint": label})

    async def diagnostics() -> None:
        while True:
            await asyncio.sleep(20)
            with (output / "async-trace.txt").open("w", encoding="utf-8") as trace:
                trace.write(f"App exception: {getattr(app, '_exception', None)!r}\n")
                for task in asyncio.all_tasks():
                    task.print_stack(file=trace)
            if getattr(app, "_exception", None):
                app.exit()
                return

    diagnostic_task = asyncio.create_task(diagnostics())

    @asynccontextmanager
    async def running_ui():
        if not args.visible:
            async with app.run_test(size=(118, 38)) as pilot:
                yield pilot
            return
        ready = asyncio.get_running_loop().create_future()
        finished = asyncio.Event()

        async def drive(pilot):
            ready.set_result(pilot)
            await finished.wait()
            app.exit()

        # A visible demo uses normal application startup/shutdown and the real
        # terminal size, including resize events. run_test fixes the viewport.
        task = asyncio.create_task(app.run_async(auto_pilot=drive))
        pilot = await ready
        app._set_active()
        try:
            yield pilot
        finally:
            finished.set()
            await task
            if app._exception:
                raise app._exception

    async with running_ui() as pilot:
        await pilot.pause(1)
        if args.capture_signal:
            signal = args.capture_signal.resolve()
            signal.mkdir(parents=True, exist_ok=True)
            if app.size.width < 140 or app.size.height < 40:
                raise AssertionError(f"Full-window capture needs a maximized terminal; actual size is {app.size}")
            (signal / "ui-ready.json").write_text(json.dumps({"evidence": str(output),
                "terminal_size": list(app.size), "native_terminal_size": list(os.get_terminal_size()),
                "app_started_monotonic": started}), encoding="utf-8")
            deadline = time.monotonic() + 60
            while not (signal / "recording-started").exists():
                if time.monotonic() > deadline:
                    raise TimeoutError("Full-window recorder did not start")
                await asyncio.sleep(0.1)
            await pilot.pause(3)
        capture("home")
        if not args.visible:
            for width, height in ((80, 24), (160, 50), (118, 38)):
                await pilot.resize_terminal(width, height)
                await pilot.pause(0.2)
                assert app.size.width == width and app.size.height == height
                prompt = app.screen.query_one(PromptInput)
                assert prompt.region.right <= width, "Prompt overflowed after resize"
            report["checks"]["resize_layout"] = True
        if args.record:
            app.set_interval(0.5, capture)
        await pilot.press("f1")
        await pilot.pause(0.5)
        assert isinstance(app.screen, HelpScreen), "Help did not open"
        capture("help")
        await pilot.press("escape", "ctrl+o")
        await pilot.pause(0.5)
        assert isinstance(app.screen, OptionsModal), "Options did not open"
        original_profile = app.runtime_config.local_profile
        app.screen.query_one("#local-profiles", RadioSet).focus()
        await pilot.press("down", "space")
        await pilot.pause(0.4)
        assert app.runtime_config.local_profile != original_profile, "Profile selection did not change"
        report["checks"]["profile_selection"] = True
        capture("profile-selection")
        # Restore the default assumptions before collecting responses.
        await pilot.press("up", "space", "escape")
        await pilot.pause(0.4)
        assert app.runtime_config.local_profile == original_profile

        async def submit(question: str, label: str, route: str | None, contains: str | None = None, same_chat=False):
            if not same_chat and not isinstance(app.screen, HomeScreen):
                app.screen.query_one(PromptInput).focus()
                await pilot.press("escape")
                await pilot.pause(0.5)
            old_count = len(app.screen.query_one(Chat).chat_data.messages) if same_chat else 0
            prompt = app.screen.query_one(PromptInput)
            prompt.clear()
            prompt.focus()
            await pilot.press(*list(question))
            await pilot.pause(0.5)
            capture(label + "-prompt")
            await pilot.press("ctrl+j")
            await pilot.pause(0.5)
            deadline = time.monotonic() + 65
            while time.monotonic() < deadline:
                chat = app.screen.query_one(Chat)
                ready = chat.allow_input_submit and chat.query_one(PromptInput).submit_ready
                answers = [m for m in chat.chat_data.messages[old_count:] if m.message["role"] == "assistant"]
                failed = bool(list(chat.query(".routing-error")))
                if ready and (answers or failed):
                    break
                await pilot.pause(0.2)
            else:
                capture(label + "-timeout")
                raise AssertionError(f"{label}: no completed response within 65 seconds")
            assert not chat.query_one(ResponseStatus).display, f"{label}: status stuck"
            if route is None:
                assert failed and not answers, f"{label}: expected a visible missing-key failure"
                assert prompt.text == question or chat.query_one(PromptInput).text == question
                result = {"case": label, "prompt": question, "expected_failure": True, "input_recovered": ready}
            else:
                assert answers, f"{label}: request failed instead of answering"
                answer = answers[-1]
                meta = answer.metadata or {}
                assert meta.get("route") == route, f"{label}: unexpected route {meta}"
                text = str(answer.message["content"])
                if contains:
                    assert contains.casefold() in text.casefold(), f"{label}: missing {contains!r} in {text!r}"
                result = {"case": label, "prompt": question, "text": text, "metadata": meta, "chat_id": chat.chat_data.id}
            report["results"].append(result)
            await pilot.pause(2 if args.visible else 0.4)
            capture(label)
            print(json.dumps({"case": label, "passed": True}), flush=True)
            return chat.chat_data.id

        paris_id = await submit("What is the capital of France?", "local-answer", "local", "Paris")
        await submit("Explain whether a triangle has three sides.", "keyword-boundaries", "local", "three")
        await submit("What is the weather in Toronto right now?", "live-weather", "api_check", "Open-Meteo")
        await submit("BTC price now", "live-crypto", "api_check", "Coinbase")
        await submit("Latest technology news", "live-news", "api_check", "BBC")
        if os.getenv("OPENAI_API_KEY"):
            await submit("Explain quantum entanglement in two sentences.", "cloud-answer", "cloud")
        else:
            await submit("Explain quantum entanglement in two sentences.", "cloud-missing-key", None)
        label = "local-after-cloud" if os.getenv("OPENAI_API_KEY") else "retry-after-cloud"
        await submit("What is 2 + 2? Answer with the number only.", label, "local", "4", same_chat=True)
        report["checks"]["failure_then_retry"] = None if os.getenv("OPENAI_API_KEY") else True

        # Reopen an earlier conversation using the actual history widget.
        app.screen.query_one(PromptInput).focus()
        await pilot.press("escape")
        await pilot.pause(0.6)
        history = app.screen.query_one(ChatList)
        index = next(i for i, item in enumerate(history.options) if item.chat.id == paris_id)
        history.highlighted = index
        history.focus()
        await pilot.press("enter")
        await pilot.pause(0.7)
        loaded = await ChatsManager.get_chat(paris_id)
        answer = next(m for m in loaded.messages if m.message["role"] == "assistant")
        assert answer.metadata["route"] == "local"
        boxes = [b for b in app.screen.query(Chatbox) if b.message.message["role"] == "assistant"]
        assert boxes and "Local" in str(boxes[-1].border_title), "Persisted route label lost"
        report["checks"]["history_source_label"] = True
        capture("reopened-history")
        app.screen.query_one(PromptInput).focus()
        await pilot.press("ctrl+r")
        await pilot.pause(0.4)
        assert isinstance(app.screen, RenameChat), "Rename dialog did not open"
        await pilot.press(*list("Local routing check"), "enter")
        await pilot.pause(0.6)
        assert (await ChatsManager.get_chat(paris_id)).title == "Local routing check"
        report["checks"]["rename_persistence"] = True
        capture("renamed-chat")
        await pilot.press("f2")
        await pilot.pause(0.4)
        assert isinstance(app.screen, ChatDetails), "Chat details did not open"
        report["checks"]["chat_details"] = True
        capture("chat-details")
        await pilot.press("escape")
        app.screen.query_one(PromptInput).focus()
        await pilot.press("escape")
        await pilot.pause(0.5)
        history = app.screen.query_one(ChatList)
        history.highlighted = next(i for i, item in enumerate(history.options) if item.chat.id == paris_id)
        history.focus()
        await pilot.press("a")
        await pilot.pause(0.5)
        assert all(item.chat.id != paris_id for item in history.options)
        assert all(chat.id != paris_id for chat in await ChatsManager.all_chats())
        report["checks"]["archive_from_history"] = True
        capture("archived-chat")
        if args.capture_signal:
            (args.capture_signal / "ui-done").write_text("done", encoding="utf-8")
        await pilot.pause(4 if args.visible else 0.2)
    await engine.dispose()
    diagnostic_task.cancel()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--visible", action="store_true")
    parser.add_argument("--record", action="store_true")
    parser.add_argument("--capture-signal", type=Path, help="Coordinate actual full-window recording")
    args = parser.parse_args()
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = ROOT / "output" / "evidence" / stamp
    output.mkdir(parents=True)
    trace = (output / "thread-trace.txt").open("w", encoding="utf-8")
    faulthandler.dump_traceback_later(90, repeat=True, file=trace)
    source_files = [p for base in (ROOT / "SEVEN", ROOT / "apps/elia/elia_chat", ROOT / "tools") for p in base.rglob("*.py")]
    source_files += [ROOT / "apps/elia/elia_chat/elia.scss", ROOT / "cli.py", ROOT / "Start-SEVEN.ps1"]
    with zipfile.ZipFile(output / "source-snapshot.zip", "w", zipfile.ZIP_DEFLATED) as snapshot:
        for path in source_files:
            snapshot.write(path, str(path.relative_to(ROOT)))
        for path in (ROOT / "tools").glob("*.ps1"):
            snapshot.write(path, str(path.relative_to(ROOT)))
    (output / "changes.patch").write_bytes(subprocess.check_output(["git", "diff", "--binary", "HEAD"], cwd=ROOT))
    report = {"utc": stamp, "capture_method": "Real Textual application and Pilot keyboard events; native renderer frames, no mocked providers or responses.",
              "visible": args.visible, "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
              "source_sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files},
              "scope": "Functional routing and interface verification, not an answer-quality benchmark. Original model replies are retained.",
              "checks": {}, "results": [], "frames": [], "passed": False}
    try:
        asyncio.run(walkthrough(args, output, report))
        report["passed"] = True
    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        faulthandler.cancel_dump_traceback_later()
        trace.close()
        (output / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"Evidence: {output}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
