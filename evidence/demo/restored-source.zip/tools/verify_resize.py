"""Check home layout resizing through normal app mode, without inference calls."""
import asyncio
import datetime as dt
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "apps/elia")]
output = ROOT / "output/evidence" / ("resize-" + dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ"))
os.environ["XDG_DATA_HOME"] = str(output / "data")
os.environ["XDG_CONFIG_HOME"] = str(output / "config")

from elia_chat.app import Elia
from elia_chat.config import LaunchConfig
from elia_chat.database.database import create_database, engine
import elia_chat.database.models
from elia_chat.widgets.prompt_input import PromptInput
from textual.events import Resize
from textual.geometry import Size


async def main():
    await create_database()
    app = Elia(LaunchConfig())
    report = {"mode": "Headless layout with an unrestricted initial viewport and injected resize events; not a desktop screen capture", "sizes": [], "passed": False}

    async def exercise(pilot):
        try:
            assert app._driver._size is None, "Normal mode unexpectedly forces a viewport"
            for width, height in ((80, 24), (160, 50), (100, 30), (190, 48), (118, 38)):
                size = Size(width, height)
                app._driver._size = size
                app.post_message(Resize(size, size))
                await pilot.pause(0.2)
                prompt = app.screen.query_one(PromptInput)
                assert tuple(app.size) == (width, height)
                assert prompt.region.right <= width
                assert prompt.region.width > 0
                report["sizes"].append({"columns": width, "rows": height, "prompt_width": prompt.region.width})
            report["passed"] = True
        finally:
            app.exit()

    try:
        async with app.run_test(size=None) as pilot:
            await exercise(pilot)
    finally:
        await engine.dispose()
        (output / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    print(f"Evidence: {output}")


if __name__ == "__main__":
    asyncio.run(main())
