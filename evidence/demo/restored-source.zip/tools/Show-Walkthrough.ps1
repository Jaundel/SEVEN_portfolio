$ErrorActionPreference = 'Stop'
$env:TERM = 'xterm-256color'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
$Host.UI.RawUI.WindowTitle = 'SEVEN live walkthrough'
Clear-Host
& (Join-Path $projectRoot '.venv\Scripts\python.exe') -X utf8 (Join-Path $PSScriptRoot 'verify_tui.py') --visible --record
$walkthroughExitCode = $LASTEXITCODE
Clear-Host
if ($walkthroughExitCode -eq 0) {
    Write-Host 'SEVEN walkthrough passed. Evidence is saved under output/evidence.' -ForegroundColor Green
} else {
    Write-Host 'SEVEN walkthrough failed. See the latest output/evidence report.' -ForegroundColor Red
}
