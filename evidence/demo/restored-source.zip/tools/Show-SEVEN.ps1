# Open the normal interactive app with its native colours in this terminal.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
$Host.UI.RawUI.WindowTitle = 'SEVEN'
Remove-Item Env:NO_COLOR -ErrorAction SilentlyContinue
$env:TEXTUAL_COLOR_SYSTEM = 'truecolor'
$env:TERM = 'xterm-256color'
Clear-Host
& (Join-Path $projectRoot 'Start-SEVEN.ps1')
