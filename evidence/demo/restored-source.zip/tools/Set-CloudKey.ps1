# Manual, masked entry of an existing OpenAI key. Never pass keys as arguments.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$targetPath = Join-Path $projectRoot '.env.local'
$Host.UI.RawUI.WindowTitle = 'SEVEN - secure OpenAI key entry'
try {
    $trackedTarget = & git -C $projectRoot ls-files -- .env.local
    if ($trackedTarget) { throw 'Refusing to write a credential into a tracked file.' }
    & git -C $projectRoot check-ignore -q -- .env.local
    if ($LASTEXITCODE -ne 0) { throw '.env.local must be ignored by Git before saving a key.' }
    if ((Test-Path -LiteralPath $targetPath) -and ((Get-Item -LiteralPath $targetPath).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'Refusing to write through a linked credential file.'
    }
    Write-Host 'SEVEN: enter your existing OpenAI API key.'
    Write-Host "Destination: $targetPath (OPENAI_API_KEY)"
    Write-Host 'Input is hidden. Press Enter to save, or leave empty to cancel.'
    $secretInput = Read-Host 'OpenAI API key' -AsSecureString
    if ($secretInput.Length -eq 0) { Write-Host 'Canceled. No key saved.'; return }
    $secretPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secretInput)
    try {
        $keyText = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($secretPointer).Trim()
        if ($keyText -notmatch '^sk-[A-Za-z0-9_-]+$') { throw 'The input does not look like an OpenAI API key. Nothing was saved.' }
        $existingText = if (Test-Path -LiteralPath $targetPath) { [IO.File]::ReadAllText($targetPath) } else { '' }
        $keyLine = 'OPENAI_API_KEY=' + $keyText
        if ($existingText -match '(?m)^\s*(?:export\s+)?OPENAI_API_KEY\s*=') {
            $updatedText = [regex]::Replace($existingText, '(?m)^\s*(?:export\s+)?OPENAI_API_KEY\s*=.*$', [Text.RegularExpressions.MatchEvaluator]{ param($match) $keyLine })
        } else {
            $updatedText = $existingText.TrimEnd() + [Environment]::NewLine + $keyLine + [Environment]::NewLine
        }
        [IO.File]::WriteAllText($targetPath, $updatedText, (New-Object Text.UTF8Encoding($false)))
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secretPointer)
        $keyText = $null
        $keyLine = $null
        $updatedText = $null
        $existingText = $null
        $secretInput.Dispose()
    }
    Write-Host 'Saved OPENAI_API_KEY securely to the ignored local env file.' -ForegroundColor Green
    Write-Host 'You can close this window. Codex will verify the cloud route.'
} catch {
    # Do not echo exception details that could contain input or file contents.
    Write-Host 'The key was not saved. Check that this is an OpenAI key and the env file is local and ignored.' -ForegroundColor Red
    exit 1
}
