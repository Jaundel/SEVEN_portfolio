param([Parameter(Mandatory=$true)][string]$SignalDirectory)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $projectRoot
Remove-Item Env:NO_COLOR -ErrorAction SilentlyContinue
$env:TEXTUAL_COLOR_SYSTEM = 'truecolor'
$env:TERM = 'xterm-256color'
Clear-Host
& (Join-Path $projectRoot '.venv\Scripts\python.exe') -X utf8 (Join-Path $PSScriptRoot 'verify_tui.py') --visible --record --capture-signal $SignalDirectory
Clear-Host
Write-Host 'Full-window SEVEN capture finished. Evidence is under output/full-window.'
