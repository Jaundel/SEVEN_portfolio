"""Prepare a Ryzen AI runtime copy without editing cached model files."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def prepare(source: Path, destination: Path) -> Path:
    source = source.resolve()
    destination = destination.resolve()
    if source == destination or source in destination.parents:
        raise ValueError('Runtime must be separate from the source model cache.')
    config_path = source / 'tokenizer_config.json'
    config = json.loads(config_path.read_text(encoding='utf-8'))
    template = source / 'chat_template.jinja'
    if not config.get('chat_template'):
        config['chat_template'] = template.read_text(encoding='utf-8')
    destination.mkdir(parents=True, exist_ok=True)
    for file in source.iterdir():
        if not file.is_file() or file.name == 'tokenizer_config.json':
            continue
        target = destination / file.name
        if target.exists() and not os.path.samefile(file, target):
            raise ValueError(f'Runtime contains a different model file: {target.name}. Choose a fresh runtime directory.')
        if not target.exists():
            os.link(file, target)
    runtime_config = destination / 'tokenizer_config.json'
    if runtime_config.exists() and os.path.samefile(config_path, runtime_config):
        raise ValueError('Runtime tokenizer configuration must not be linked to the source cache.')
    runtime_config.write_text(json.dumps(config, indent=2), encoding='utf-8')
    record = {'source_revision': source.name,
        'source_tokenizer_sha256': hashlib.sha256(config_path.read_bytes()).hexdigest(),
        'runtime_tokenizer_sha256': hashlib.sha256((destination / 'tokenizer_config.json').read_bytes()).hexdigest(),
        'method': 'Hardlink cached weights; copy tokenizer configuration and expose bundled Jinja chat template.'}
    (destination.parent / 'runtime-manifest.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
    return destination


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-dir', type=Path)
    args = parser.parse_args()
    source = args.model_dir
    if source is None:
        cache = Path.home() / '.cache/huggingface/hub/models--amd--Llama-3.2-1B-Instruct-onnx-ryzenai-1.7-hybrid/snapshots'
        snapshots = sorted(cache.glob('*/tokenizer_config.json'), key=lambda p:p.stat().st_mtime, reverse=True)
        if not snapshots:
            parser.error('Cached Ryzen AI model not found. Install a model in Lemonade, or pass --model-dir.')
        source = snapshots[0].parent
    print(prepare(source, ROOT / 'output/runtime/llama-model'))


if __name__ == '__main__':
    main()
