"""Capture an entire named GPU-composited window, preserving native pixels."""
import json
from pathlib import Path
import subprocess
import sys
import threading
import time

import imageio_ffmpeg
from windows_capture import WindowsCapture


def main():
    title, destination = sys.argv[1:3]
    folder = Path(destination)
    lock = threading.Lock()
    latest = None
    capture = WindowsCapture(cursor_capture=False, draw_border=False, window_name=title,
                             minimum_update_interval=50)

    @capture.event
    def on_frame_arrived(frame, control):
        nonlocal latest
        with lock:
            latest = frame.convert_to_bgr().frame_buffer.copy()

    @capture.event
    def on_closed():
        pass

    controller = capture.start_free_threaded()
    deadline = time.monotonic() + 20
    while latest is None:
        if time.monotonic() > deadline:
            raise TimeoutError('Windows Graphics Capture returned no window frames')
        time.sleep(.1)
    with lock:
        first = latest.copy()
    height, width = first.shape[:2]
    assert first.std() > 3, 'Blank first frame; refusing to record'
    import cv2
    cv2.imwrite(str(folder / 'recorder-probe.png'), first)
    fps = 15
    with (folder/'capture.log').open('w',encoding='utf-8') as log:
        recorder = subprocess.Popen([imageio_ffmpeg.get_ffmpeg_exe(),'-hide_banner','-y',
            '-f','rawvideo','-pixel_format','bgr24','-video_size',f'{width}x{height}',
            '-framerate',str(fps),'-i','pipe:0','-an','-c:v','libx264','-preset','veryfast',
            '-crf','20','-vf','pad=ceil(iw/2)*2:ceil(ih/2)*2','-pix_fmt','yuv420p',
            '-movflags','+faststart',str(folder/'seven-full-window.mp4')],stdin=subprocess.PIPE,stderr=log)
        started=time.monotonic()
        (folder/'recorder-ready.json').write_text(json.dumps({'width':width,'height':height,
            'record_start_monotonic':started,'frame_std':float(first.std())}))
        n=0
        while not (folder/'recording-stop').exists() and time.monotonic()-started < 125:
            with lock:
                frame=latest.copy()
            assert frame.shape == first.shape, 'Window resized during capture'
            recorder.stdin.write(frame.tobytes())
            n+=1
            time.sleep(max(0, started+n/fps-time.monotonic()))
        recorder.stdin.close()
        recorder.wait(timeout=20)
        assert recorder.returncode==0
    controller.stop()
    (folder/'recorder-result.json').write_text(json.dumps({'frames':n,'fps':fps,'duration_s':n/fps}))


if __name__=='__main__':main()
