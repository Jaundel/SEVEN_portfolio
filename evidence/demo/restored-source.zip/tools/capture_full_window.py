"""Record the complete maximized SEVEN window using FFmpeg's Windows GDI input.

No terminal size, crop rectangle or video size is imposed. UI actions use
the application's own Pilot API, and no keys or personal chats are captured.
"""
import datetime as dt
import json
from pathlib import Path
import re
import subprocess
import sys
import time

import imageio_ffmpeg

ROOT = Path(__file__).resolve().parents[1]


def main():
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    folder = ROOT / "output/full-window" / stamp
    folder.mkdir(parents=True)
    title = "SEVEN-CAPTURE-" + stamp
    subprocess.Popen(["wt.exe", "--maximized", "-w", "new", "new-tab", "--title", title,
        "--suppressApplicationTitle", "-d", str(ROOT), "powershell.exe", "-NoProfile", "-NoExit", "-File",
        str(ROOT / "tools/Show-FullCapture.ps1"), "-SignalDirectory", str(folder)])
    deadline = time.monotonic() + 60
    while not (folder / "ui-ready.json").exists():
        if time.monotonic() > deadline:
            raise TimeoutError("Maximized SEVEN window did not become ready")
        time.sleep(0.2)
    ready = json.loads((folder / "ui-ready.json").read_text())
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    video = folder / "seven-full-window.mp4"
    recorder = subprocess.Popen([sys.executable, str(ROOT/'tools/window_recorder.py'), title, str(folder)])
    deadline=time.monotonic()+25
    while not (folder/'recorder-ready.json').exists():
        if recorder.poll() is not None or time.monotonic()>deadline:
            raise RuntimeError('Graphics window recorder did not become ready')
        time.sleep(.1)
    recording=json.loads((folder/'recorder-ready.json').read_text())
    record_start=recording['record_start_monotonic']
    (folder / "recording-started").write_text("ready")
    deadline = time.monotonic() + 125
    while not (folder / "ui-done").exists():
        if recorder.poll() is not None or time.monotonic() > deadline:
            raise RuntimeError("Walkthrough or recorder stopped before completion")
        time.sleep(0.2)
    (folder/'recording-stop').write_text('stop')
    recorder.wait(timeout=25)
    if recorder.returncode:
        raise RuntimeError("FFmpeg did not finish cleanly")
    evidence = Path(ready["evidence"])
    deadline = time.monotonic() + 15
    while not (evidence / "report.json").exists():
        if time.monotonic() > deadline:
            raise TimeoutError("Final UI report missing")
        time.sleep(0.2)
    report = json.loads((evidence / "report.json").read_text())
    assert report["passed"], "UI verification failed"
    width, height = recording['width'],recording['height']
    assert width >= 1600 and height >= 900, f"Capture is too small: {width}x{height}"
    offset = record_start - ready["app_started_monotonic"]
    checkpoints = []
    for frame in report["frames"]:
        label = frame.get("checkpoint")
        if label in {"home", "local-answer", "live-weather", "live-crypto", "live-news", "cloud-answer", "profile-selection", "reopened-history"}:
            seconds = max(0, frame["elapsed_s"] - offset - 0.3)
            png = folder / (label + ".png")
            subprocess.run([ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-ss", str(seconds),
                "-i", str(video), "-frames:v", "1", str(png)], check=True)
            checkpoints.append({"label": label, "seconds": seconds, "image": png.name})
    manifest = {"utc": stamp, "method": "Windows Graphics Capture of the complete maximized Windows Terminal window selected by unique title; native observed dimensions, no crop or resize. FFmpeg H.264 encoding; unchanged frames repeated at 15 fps to preserve wall time.",
        "window_title": title, "width": width, "height": height, "terminal_size": ready["terminal_size"],
        "video": video.name, "bytes": video.stat().st_size, "source_report": str(evidence / "report.json"),
        "checks": report["checks"], "checkpoints": checkpoints, "ffmpeg_exit": recorder.returncode}
    (folder / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))
    print(f"Full-window evidence: {folder}")


if __name__ == "__main__":
    main()
