"""Render an actual verify_tui.py recording to PNG frames and MP4.

The video preserves the renderer's captured frame order and elapsed times.
Requires optional requirements-demo.txt packages; does not generate app content.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess

import imageio_ffmpeg
from PIL import Image
import resvg_py


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path, help="Evidence directory containing report.json")
    args = parser.parse_args()
    run = args.run.resolve()
    report = json.loads((run / "report.json").read_text(encoding="utf-8"))
    if not report["passed"]:
        raise SystemExit("Only render a verified walkthrough; report.passed must be true.")
    frames = report["frames"]
    rendered = run / "rendered"
    rendered.mkdir(exist_ok=True)
    font_root = Path("C:/Windows/Fonts")
    fonts = [str(p) for p in (font_root / "consola.ttf", font_root / "consolab.ttf") if p.exists()]
    concat = []
    dimensions = [0, 0]
    for index, frame in enumerate(frames):
        name = f"frame-{index:05d}.png"
        png = resvg_py.svg_to_bytes(svg_path=str(run / "frames" / frame["file"]),
                                   font_files=fonts, monospace_family="Consolas")
        (rendered / name).write_bytes(png)
        with Image.open(rendered / name) as frame_image:
            dimensions[0] = max(dimensions[0], frame_image.width)
            dimensions[1] = max(dimensions[1], frame_image.height)
        next_time = frames[index + 1]["elapsed_s"] if index + 1 < len(frames) else frame["elapsed_s"] + 2
        concat += [f"file '{name}'", f"duration {max(0.04, next_time - frame['elapsed_s']):.6f}"]
        if frame.get("checkpoint") == "local-answer":
            (run / "seven-poster.png").write_bytes(png)
    concat += [f"file 'frame-{len(frames) - 1:05d}.png'"]
    listing = rendered / "frames.txt"
    listing.write_text("\n".join(concat) + "\n", encoding="utf-8")
    # A real window can resize during capture. Keep each full frame and pad
    # smaller frames rather than stretching text or cropping application output.
    dimensions = [value + value % 2 for value in dimensions]
    for frame in rendered.glob("frame-*.png"):
        with Image.open(frame) as original:
            if original.size != tuple(dimensions):
                canvas = Image.new("RGB", dimensions, "#0b0b12")
                canvas.paste(original.convert("RGB"), (0, 0))
                canvas.save(frame)
    video = run / "seven-walkthrough.mp4"
    command = [imageio_ffmpeg.get_ffmpeg_exe(), "-hide_banner", "-loglevel", "error", "-y",
               "-f", "concat", "-safe", "1", "-i", str(listing),
               "-vf", "pad=ceil(iw/2)*2:ceil(ih/2)*2", "-r", "10",
               "-c:v", "libx264", "-crf", "20", "-pix_fmt", "yuv420p",
               "-movflags", "+faststart", str(video)]
    subprocess.run(command, check=True)
    metadata = {"method": "Native Textual renderer frames from a real UI walkthrough, replayed at their captured times.",
                "frame_count": len(frames), "duration_s": frames[-1]["elapsed_s"] - frames[0]["elapsed_s"] + 2,
                "dimensions": dimensions, "video_bytes": video.stat().st_size,
                "source_report": str(run / "report.json")}
    (run / "video.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps({"video": str(video), **metadata}, indent=2))


if __name__ == "__main__":
    main()
