# ============================================================
#  File: cli.py
#  Project: SEVEN (Sustainable Energy via Efficient Neural-routing)
#  Description: CLI entry point for SEVEN - launches the TUI with intelligent routing.
#  Author(s): Team SEVEN
#  Date: 2025-11-18
# ============================================================
"""Launch the SEVEN TUI - an energy-aware AI chat interface with intelligent routing."""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
ELIA_APP_DIR = REPO_ROOT / "apps" / "elia"


def _bootstrap_paths() -> None:
    """Ensure both the Elia app and SEVEN package are importable."""
    for path in (ELIA_APP_DIR, REPO_ROOT):
        path_str = str(path)
        if path_str not in sys.path:
            sys.path.insert(0, path_str)


def _ensure_database_exists() -> None:
    """Create missing tables, including in an existing empty database file."""
    from elia_chat.database.database import create_database, engine, sqlite_file_name
    # Import models to ensure they're registered with SQLModel metadata
    import elia_chat.database.models  # noqa: F401

    if not sqlite_file_name.exists():
        print(f"Creating database at {sqlite_file_name}")

    async def prepare_database() -> None:
        await create_database()
        # The interactive app starts its own event loop after this bootstrap.
        await engine.dispose()

    asyncio.run(prepare_database())


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Launch SEVEN (Sustainable Energy Via Efficient Neural-routing) - "
        "Routes prompts to a local model, live tools, or a cloud model and reports "
        "configured energy estimates."
    )
    parser.add_argument(
        "-p",
        "--prompt",
        default="",
        help="Optional prompt to pre-populate when SEVEN opens.",
    )
    return parser.parse_args()


def main() -> None:
    if any(arg in sys.argv for arg in ('--ask', '--classify', '--doctor')):
        from SEVEN.main import main as command_main
        raise SystemExit(command_main())
    from SEVEN.settings import load_settings
    load_settings()
    os.environ['SEVEN_NO_SPINNER'] = '1'
    args = parse_args()
    _bootstrap_paths()
    _ensure_database_exists()

    from elia_chat.app import Elia
    from elia_chat.config import LaunchConfig

    config = LaunchConfig.get_current()
    app = Elia(config=config, startup_prompt=args.prompt)
    app.run()


if __name__ == "__main__":
    main()
