# Recorded SEVEN application

The Python, PowerShell and SCSS files come byte-for-byte from source-snapshot.zip, captured with the November 14, 2026 full-window walkthrough. Setup documents, package metadata, dependency lists and the Elia MIT licence were added from the restored checkout during packaging. They are not measured results.

Start with SETUP.md. No environment files, credentials, chat databases, runtime binaries or model weights are included. The Ryzen AI launcher expects the runtime already installed; another compatible backend can use the documented Python entry point.

The terminal interface adapts Darren Burns' Elia; retain apps/elia/LICENSE. Original team roles are in README.md. Do not infer that SEVEN authored Elia.
