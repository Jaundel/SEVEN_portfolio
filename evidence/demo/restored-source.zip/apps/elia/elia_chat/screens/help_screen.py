from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Footer, Markdown


class HelpScreen(ModalScreen[None]):
    BINDINGS = [
        Binding("q", "app.quit", "Quit", show=False),
        Binding("escape,f1,?", "app.pop_screen()", "Close help", key_display="esc"),
    ]

    HELP_MARKDOWN = """\
### How do I quit SEVEN?

Press `Ctrl+C` on your keyboard.
`q` also works if an input isn't currently focused.
If focus is on the prompt input box on the home screen, `esc` will close SEVEN too.

### Backends and live data

Run `python cli.py --doctor` to inspect local backend readiness and credential presence.
Local inference needs a running Lemonade-compatible server. Startup loads `.env.local`
from the SEVEN repository, then `.env`; exported variables take precedence.

OpenAI handles cloud routes and needs `OPENAI_API_KEY`. Weather (Open-Meteo),
crypto spot quotes (Coinbase) and news feeds (BBC RSS) work without keys for this
personal CLI. Missing data is shown explicitly. No model invents current facts.

### Energy profiles

`ctrl+o` changes the assumptions used by the estimator. It does not switch the
running model or hardware. Energy numbers are profile estimates, not measurements.

### Config file and database

The locations of the config file and the database can be found at the bottom
of the options screen (`ctrl+o`).

### General navigation

SEVEN has very strong mouse support. Most things can be clicked.

Use `tab` and `shift+tab` to move between different widgets on screen.

In some places you can make use of the arrow keys or Vim nav keys to move around.

In general, pressing `esc` will move you "closer to home".
Pay attention to the bar at the bottom to see where `esc` will take you.

If you can see a scrollbar, `pageup`, `pagedown`, `home`, and `end` can also
be used to navigate.

On the chat screen, pressing `up` and `down` will navigate through messages,
but if you just wish to scroll a little, you can use `shift+up` and `shift+down`.

### The chat list

- `up,down,k,j`: Navigate through chats.
- `a`: Archive the highlighted chat.
- `pageup,pagedown`: Up/down a page.
- `home,end`: Go to first/last chat.
- `g,G`: Go to first/last chat.
- `enter,l`: Open chat.

### The options window

Press `ctrl+o` to open the _options window_.

This window selects local and cloud assumptions for the energy estimator.
Changes apply immediately to the current session. They do not change the
running model or hardware. The data and configuration paths appear below
the profile selectors.

### Writing a prompt

The shortcuts below work when the _prompt editor_ is focused.
The prompt editor is the box where you type your message.
It's present on both the home screen and the chat page.

- `ctrl+j`: Submit the prompt
- `alt+enter`: Submit the prompt (only works in some terminals)
- `up`: Move the cursor up
- `down`: Move the cursor down
- `left`: Move the cursor left
- `ctrl+left`: Move the cursor to the start of the word
- `ctrl+shift+left`: Move the cursor to the start of the word and select
- `right`: Move the cursor right
- `ctrl+right`: Move the cursor to the end of the word
- `ctrl+shift+right`: Move the cursor to the end of the word and select
- `home,ctrl+a`: Move the cursor to the start of the line
- `end,ctrl+e`: Move the cursor to the end of the line
- `shift+home`: Move the cursor to the start of the line and select
- `shift+end`: Move the cursor to the end of the line and select
- `pageup`: Move the cursor one page up
- `pagedown`: Move the cursor one page down
- `shift+up`: Select while moving the cursor up
- `shift+down`: Select while moving the cursor down
- `shift+left`: Select while moving the cursor left
- `backspace`: Delete character to the left of cursor
- `ctrl+w`: Delete from cursor to start of the word
- `delete,ctrl+d`: Delete character to the right of cursor
- `ctrl+f`: Delete from cursor to end of the word
- `ctrl+x`: Delete the current line
- `ctrl+u`: Delete from cursor to the start of the line
- `ctrl+k`: Delete from cursor to the end of the line
- `f6`: Select the current line
- `f7`: Select all text in the document
- `ctrl+z`: Undo last edit
- `ctrl+y`: Redo last undo
- `cmd+v` (mac): Paste
- `ctrl+v` (windows/linux): Paste

You can also click to move the cursor, and click and drag to select text.

The arrow keys can also be used to move focus _out_ of the prompt box.
For example, pressing `up` while the prompt is focussed on the chat screen
and the cursor is at (0, 0) will move focus to the latest message.

### The chat screen

You can use the arrow keys to move up and down through messages.

- `ctrl+r`: Rename the chat (or click the chat title).
- `f2`: View more information about the chat.

_With a message focused_:

- `y,c`: Copy the raw Markdown of the message to the clipboard.
    - This requires terminal support. The default MacOS terminal is not supported.
- `enter`: Enter _select mode_.
    - In this mode, you can move a cursor through the text, optionally holding
        `shift` to select text as you move.
    - Press `v` to toggle _visual mode_, allowing you to select without text without
        needing to hold `shift`.
    - Press `u` to quickly select the next code block in the message.
    - With some text selected, press `y` or c` to copy.
- `enter`: View more details about a message.
    - The amount of details available may vary depending on the model
        or provider being used.
- `g`: Focus the first message.
- `G`: Focus the latest message.
- `m`: Move focus to the prompt box.
- `up,down,k,j`: Navigate through messages.

"""

    def compose(self) -> ComposeResult:
        with Vertical(id="help-container") as vertical:
            vertical.border_title = "SEVEN Help"
            with VerticalScroll():
                yield Markdown(self.HELP_MARKDOWN, id="help-markdown")
            yield Markdown(
                "Use `pageup`, `pagedown`, `up`, and `down` to scroll.",
                id="help-scroll-keys-info",
            )
        yield Footer()
