"""Show a welcome box on the home page when the user has
no chat history.
"""

from rich.console import RenderableType
from textual.widgets import Static


class Welcome(Static):
    MESSAGE = """
[b]SEVEN[/] · Choose where your AI runs.

[b cyan]LOCAL[/]  Short general questions run on your configured local model.
[b yellow]LIVE DATA[/]  Weather, crypto and news tools return source information directly.
[b magenta]CLOUD[/]  Complexity rules or explicit local uncertainty can send your prompt to OpenAI.

Routing rules are heuristics. A confident local answer can still be wrong.
Cloud routing sends the prompt and conversation context to your configured provider.

[b]Energy figures are estimates from selected profiles.[/]
They are not electricity measurements or verified savings. Changing a profile
changes the calculation; it does not switch your hardware or running model.

Type your question, then press [b]ctrl+j[/] or [b]alt+enter[/].
[b]ctrl+o[/]  Estimate profiles    [b]f1[/]  Help

[@click='open_repo'][b]Source and setup instructions →[/][/]
"""

    BORDER_TITLE = "SEVEN - Intelligent Routing for Sustainable AI"

    def render(self) -> RenderableType:
        return self.MESSAGE

    def _action_open_repo(self) -> None:
        import webbrowser

        webbrowser.open("https://github.com/Jaundel/SEVEN")

    def _action_open_issues(self) -> None:
        import webbrowser

        webbrowser.open("https://github.com/Jaundel/SEVEN/issues")
